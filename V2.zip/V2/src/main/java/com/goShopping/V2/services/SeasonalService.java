package com.goShopping.V2.services;

import com.goShopping.V2.models.Product;
import com.goShopping.V2.models.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.List;

public class SeasonalService {
    @Autowired
    ProductRepository productRepository;
    public List<Product> findSeasonal(int i)
    {
        List <Product> products=productRepository.findAll();
        for(Product p:products)
        {
        }
        return new ArrayList<Product>();
    }

}
