package com.goShopping.V2.models;


import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import java.util.List;

@Entity
public class Filter {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    String name;
    @ManyToMany(mappedBy = "filters")
    @JsonIgnore
    List<Product> productsWithFilter;

    @ManyToMany(mappedBy= "filterList")
    List <Settings> settings;
    public Filter(String name)
    {
        this.name=name;
    }
    protected Filter() {
    }

    public String getName() {
        return name;
    }

    public List<Product> getProductsWithFilter() {
        return productsWithFilter;
    }
}
