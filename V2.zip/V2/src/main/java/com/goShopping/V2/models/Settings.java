package com.goShopping.V2.models;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import java.util.List;

@Entity
public class Settings {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    private boolean isFilter;
    @OneToOne(mappedBy = "settings")
    User user;

    @ManyToMany
    @JsonIgnore
    @JoinTable(
            joinColumns = @JoinColumn(name = "setting_id"),
            inverseJoinColumns = @JoinColumn(name = "filter_id"))
    List <Filter> filterList;
    protected Settings() {
    }

    public List<Filter> getFilterList() {
        return filterList;
    }
    public void setFilterList(List<Filter> filterList) {
        this.filterList = filterList;
    }
    public void addFilter(Filter filter) {filterList.add(filter);}
    public void setIsFilter(boolean isFilter) {
        this.isFilter = isFilter;
    }
    public boolean getIsFilter() {
        return isFilter;
    }

    public User getUser() {return user;}
}
