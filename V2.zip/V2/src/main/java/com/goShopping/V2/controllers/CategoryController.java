package com.goShopping.V2.controllers;

import com.goShopping.V2.models.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/categories")
public class CategoryController {
    @Autowired
    private CategoryRepository categoryRepository;
    @GetMapping("/addCategory/{name}")
    @ResponseBody
    public Category addCategory(@PathVariable("name")String name)
    {
        return categoryRepository.save(new Category(name));
    }

    @GetMapping("/{id}")
    @ResponseBody
    public Category getCategory(@PathVariable("id") long id)
    {
        return categoryRepository.findById(id).get();
    }
    /*@GetMapping("/{id}/products")
    @ResponseBody
    public List <Product> getProductsOfCategory(@PathVariable("id") long id)
    {
        Category category=categoryRepository.findById(id).get();
        return category.getProductsOfCategory();

    }*/
}
