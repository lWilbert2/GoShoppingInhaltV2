package com.goShopping.V2.models;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "user_id")
public class User {
    private String name;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @OneToOne(cascade = CascadeType.ALL)
    private Settings settings;
    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL)
    private List <ShoppingList> shoppingLists;

    public User(String name)
    {
        this.name=name;
        settings=new Settings();
    }
    protected User() {}

    public long getId() {return id;}
    public List<ShoppingList> getShoppingLists() {return shoppingLists;}
    public Settings getSettings() {return settings;}
    public void setSettings(Settings settings) {this.settings = settings;}
    public void setShoppingLists(List<ShoppingList> shoppingLists) {this.shoppingLists = shoppingLists;}
    public void addShoppingList(ShoppingList shoppingList){shoppingLists.add(shoppingList);}
}
