package com.goShopping.V2.controllers;

import com.goShopping.V2.models.*;
import com.goShopping.V2.services.ShopService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.RestController;

import java.util.*;

@RestController
@RequestMapping("users/{userId}/lists")
public class ShoppingListController {
    @Autowired
    private ShoppingListRepository shoppingListRepo;
    @Autowired
    private ProductRepository productRepo;
    @Autowired
    private ListItemRepository listItemRepository;
    @Autowired
    private ShopRepository shopRepository;


    @GetMapping("/newList/{name}")
    @ResponseBody
    public ShoppingList addList(@PathVariable("name") String name)
    {
        ShoppingList shoppingList=shoppingListRepo.save(new ShoppingList(name));
        return shoppingList;

    }

   /* @GetMapping("/{id}")
    @ResponseBody
    public List <ListItem> getItemOnList(@PathVariable("id")long id)
    {
        List <ListItem> listItems= listItemRepository.findAllOrderByPriorityDesc();
        List <ListItem> sortedListItems=new ArrayList<ListItem>();
        for(ListItem l: listItems)
        {
            if(l.getShoppingList().getId()==id)
            {
                sortedListItems.add(l);
            }
        }
        return sortedListItems;
        //return shoppingListRepo.findById(id).get().getList();

    }*/

    @GetMapping("/{id}/products/{itemId}")     //Detailproduktanzeige
    @ResponseBody
    public Product detailProduct(Model model, @PathVariable("id") Long id, @PathVariable ("itemId") Long itemId)
    {
        model.addAttribute("product",listItemRepository.findById(itemId).get().getProduct());
        return listItemRepository.findById(itemId).get().getProduct();
    }
    @GetMapping("/{id}/deleteList")
    public void deleteList(@PathVariable("id")Long id)
    {
        shoppingListRepo.deleteById(id);
    }

   @PostMapping("/{id}/addProduct/{productId}")
    public void addProductToList(@PathVariable("productId")long productId,@PathVariable("id")long listId)
    {
        ShoppingList s=shoppingListRepo.findById(listId).get();
        s.addProduct(productRepo.findById(productId).get());
        shoppingListRepo.save(s);
    }
    @GetMapping("/{id}/deleteItem/{listItemId}")
    @ResponseBody
    public ListItem deleteItemfromList(@PathVariable("id")long listId,@PathVariable("listItemId")long listItemId)
    {
        ListItem listItem=listItemRepository.findById(listItemId).get();
        if(listItem.getQuantity()>1)
        {
            listItem.setQuantity(listItem.getQuantity()-1);
            listItemRepository.save(listItem);
        }
        else
        {
            listItemRepository.deleteById(listItemId);
        }
        return listItem;
    }
   /* @GetMapping("/{id}/checkStores")  //Startseite
    @ResponseBody
    public int [] CheckStores(@PathVariable("id") long id) {
        ShoppingList shoppingList=shoppingListRepo.findById(id).get();
        List shops=shopRepository.findAll();
        ShopService shopService=new ShopService();
        return shopService.checkStoresforItems(shoppingList, shops);
    }*/
    @GetMapping("/{id}/changePriority/{itemId}/{value}")
    public List <ListItem> sortByPriority(@PathVariable("id") long id, @PathVariable("itemId") long itemId, @PathVariable("value") int value)
    {
        ShoppingList shoppingList= shoppingListRepo.findById(id).get();
        ListItem listItem=listItemRepository.findById(itemId).get();
        listItem.changePriority(value);
        listItemRepository.save(listItem);
        return shoppingList.getList();
    }
}
