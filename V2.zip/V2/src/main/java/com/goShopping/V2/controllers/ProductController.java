package com.goShopping.V2.controllers;

import com.goShopping.V2.models.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/products")
public class ProductController {
    @Autowired
    private ProductRepository productRepo;
    @Autowired
    private CategoryRepository categoryRepository;
    @Autowired
    private FilterRepository allergenRepository;

    @GetMapping("/addProduct")  //Startseite
    public void products(Model model) {
        productRepo.save(new Product("Frucht Shake", "Japan"));
        /*productRepo.save(new Product("Erdbeeren", "Deutschland"));
        productRepo.save(new Product("Mango", "Puerto Rico"));
        productRepo.save(new Product("Chinakohl", "China"));
        productRepo.save(new Product("Champions", "Russland"));
        productRepo.save(new Product("Möhren", "Niederlande"));
        productRepo.save(new Product("Aperol Spritz", "Italien"));
        productRepo.save(new Product("Gummibärchen", "Thomas Gottschalk"));
        productRepo.save(new Product("Marmelade", "Frankreich"));
        productRepo.save(new Product("Brie", "Frankreich"));
        productRepo.save(new Product("Hobbits", "Auenland"));
        productRepo.save(new Product("Edamame", "Japan"));
        productRepo.save(new Product("Rotwein", "Griechenland"));
        productRepo.save(new Product("Weißwein", "Portugal"));*/
    }
    @GetMapping("/{id}")
    @ResponseBody
    public Product getProduct(@PathVariable("id") long id)
    {
        return productRepo.findById(id).get();
    }

    @GetMapping("/{id}/addCategory/{categoryId}")
    @ResponseBody
    public Product addCategorytoProduct(@PathVariable("id") long id,@PathVariable("categoryId") long categoryId)
    {
        Product product=productRepo.findById(id).get();
        Category category=categoryRepository.findById(categoryId).get();
        product.addCategory(category);
        return productRepo.save(product);
    }
    @GetMapping("/{id}/deleteCategory/{categoryId}")
    @ResponseBody
    public Product deleteCategoryfromProduct(@PathVariable("id") long id,@PathVariable("categoryId") long categoryId)
    {
        Product product=productRepo.findById(id).get();
        product.deleteCategory(categoryRepository.findById(categoryId).get());
        return productRepo.save(product);
    }
    @GetMapping("/{id}/categories")
    @ResponseBody
    public List<Category> getCategories(@PathVariable("id") long id)
    {
        Product product=productRepo.findById(id).get();
        return product.getCategories();

    }
    @GetMapping("/{id}/filter")
    @ResponseBody
    public List <Filter> getFilter(@PathVariable("id") long id)
    {
        Product product=productRepo.findById(id).get();
        return product.getFilter();

    }
    @GetMapping("/{id}/addFilter/{filterId}")
    @ResponseBody
    public Product addFilterToProduct(@PathVariable("id") long id,@PathVariable("filterId") long filterId)
    {
        Product product=productRepo.findById(id).get();
        Filter filter=allergenRepository.findById(filterId).get();
        product.addFilter(filter);
        return productRepo.save(product);
    }
    @GetMapping("/{id}/addSpecification")
    @ResponseBody
    public Product addSpecification(@PathVariable("id") long id)
    {
        Product product=productRepo.findById(id).get();
        List <String> spe=new ArrayList<String>();
        spe.add("soja");
        spe.add(("hafer"));
        spe.add("mandel");
        spe.add("kokos");
        product.setSpecifications(spe);
        productRepo.save(product);
        return product;
    }

}
