INSERT INTO TBL_PRODUCTS (name, herkunftsland) VALUES
                                                   ('apfel', 'england' ),('hafer', 'deutschland'),('deineMutter', 'knast');