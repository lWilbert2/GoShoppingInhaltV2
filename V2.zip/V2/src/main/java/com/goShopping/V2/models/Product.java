package com.goShopping.V2.models;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
public class Product {
    @javax.persistence.Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    private long Id;
    private String name;
    private String herkunftsland;

    @ElementCollection
    private List <String> specifications;

    @ManyToMany(mappedBy = "inventory")
    @JsonIgnore
    List <Shop> shops;

    @ManyToMany(mappedBy = "seasonalProducts")
    @JsonIgnore
    List <Month> seasonal;
    @ManyToMany
    @JsonIgnore
    @JoinTable(
            joinColumns = @JoinColumn(name = "product_id"),
            inverseJoinColumns = @JoinColumn(name = "category_id"))
    List <Category> categories;

    @ManyToMany
    @JsonIgnore
    @JoinTable(
            joinColumns = @JoinColumn(name = "product_id"),
            inverseJoinColumns = @JoinColumn(name = "filter_id"))
    List <Filter> filters;


    public Product(String name, String herkunftsland) {
        this.name = name;
        this.herkunftsland = herkunftsland;
        specifications=new ArrayList<String>();
    }

    public Product(String name, String herkunftsland, List <String> specifications) {
        this.name = name;
        this.herkunftsland = herkunftsland;
        this.specifications=specifications;
    }

    protected Product() {
    }
    public void setSpecifications(List <String> specifications) {this.specifications=specifications;}
    public void addCategory(Category category)
    {
        categories.add(category);
    }
    public void deleteCategory(Category category)
    {
        categories.remove(category);
    }
    public void addFilter(Filter filter) {filters.add(filter);}
    public List <String> getSpecifications()
    {
        return specifications;
    }
    public List <Category> getCategories()
    {
        return categories;
    }
    public List <Filter> getFilter()
    {
        return filters;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getHerkunftsland() {
        return herkunftsland;
    }

    public void setHerkunftsland(String herkunftsland) {
        this.herkunftsland = herkunftsland;
    }

    public long getId() {
        return Id;
    }
}
