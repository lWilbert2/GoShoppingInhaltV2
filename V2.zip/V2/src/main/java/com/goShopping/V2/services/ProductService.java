package com.goShopping.V2.services;

import com.goShopping.V2.models.ProductRepository;
import com.goShopping.V2.models.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class ProductService {
    @Autowired
    private ProductRepository productRepo;

    public List <Product> searchProduct(String sub)
    {
        List <Product> all=productRepo.findAll();
        List <Product> found=new ArrayList<Product>();
        for(Product p:all)
        {
            if(p.getName().contains(sub))
            {
                found.add(p);
            }
        }
        return found;
    }


}
