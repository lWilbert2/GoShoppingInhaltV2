package com.goShopping.V2.controllers;

import com.goShopping.V2.models.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/{userId}")
public class UserController {

    @Autowired
    UserRepository userRepository;
    @Autowired
    ProductRepository productRepository;
    @Autowired
    ShoppingListRepository shoppingListRepository;

    @GetMapping("/lists/{listId}/products")
    public String getProducts(@PathVariable("userId") long userId, @PathVariable("listId") Long listId, Model model)
    {
        User user=userRepository.findById(userId).get();
        Settings settings=user.getSettings();
        if(settings.getIsFilter()==true)
        {
           List<Product> products=productRepository.findAll();
           List <Filter> filter=settings.getFilterList();
           for(Product p:products)
           {
               if(p.getFilter().contains(filter))
               {
                   products.remove(p);
               }
           }
           model.addAttribute("shoppinglist", shoppingListRepository.findById(listId).get());
           model.addAttribute("product",products);
        }
        else{
            model.addAttribute("shoppinglist", shoppingListRepository.findById(listId).get());
            model.addAttribute("product", productRepository.findAll());
        }
        return "products";
    }
}
