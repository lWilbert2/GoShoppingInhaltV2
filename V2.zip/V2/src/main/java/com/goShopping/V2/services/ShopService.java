package com.goShopping.V2.services;

import com.goShopping.V2.models.*;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.List;

public class ShopService {
    @Autowired
    ProductRepository productRepository;
    @Autowired
    ShopRepository shopRepository;
    @Autowired
    ShoppingListRepository shoppingListRepository;
    @Autowired
    ListItemRepository listItemRepository;

    public Shop checkStoresforItems(ShoppingList shoppingList, List <Shop> shops)
    {
        int [] counter=new int[shops.size()];
        for(int i=0; i<shops.size();i++)
        {
            counter[i]=0;
            for(ListItem listItem: shoppingList.getList())
            {
                if(shops.get(i).hasProduct(listItem.getProduct())==true)
                {
                    counter[i]++;
                }
            }
        }
        int i=0;
        for(int j=0; j<counter.length; j++)
        {
            if(counter[j]>counter[i]) i=j;
        }
        return shops.get(i);
    }




}
