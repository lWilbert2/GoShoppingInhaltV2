package com.goShopping.V2.models;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import java.util.*;

@Entity
public class ShoppingList {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    @OneToMany(mappedBy = "shoppingList", cascade = CascadeType.ALL)
    private  List <ListItem> list;

    @ManyToOne
    @JoinColumn(name="user_id")
    @JsonIgnore
    private User user;

    private String name;

   public ShoppingList(String name) {
        this.name = name;
        list=new ArrayList<ListItem>();
    }

    public void setUser(User user) {this.user = user;}
    public User getUser() {return user;}
    public ShoppingList() {}
    public List <ListItem> getList() {return list;}
    public Long getId() {return id;}
    public String getName() {return name;}
    public void setName(String name) {this.name=name;}
    public void setList(List <ListItem> list) {this.list=list;}

    public void addProduct(Product p){
        int c=checkProduct(p);
        if(c==-1)
        {
            ListItem i=new ListItem(1,p,this);
            list.add(i);
        }
        else {
            int quant=list.get(c).getQuantity();
            list.get(c).setQuantity(quant+1);
        }
    }
    private int checkProduct(Product p)
    {
       for(int i=0; i<list.size(); i++)
       {
           if(list.get(i).getProduct().getId()==p.getId())
           {
               return i;
           }
       }
       return -1;
    }
    public void deleteProduct(long listItemId) {
        for (ListItem lI : list) {
            if (lI.getId() == listItemId) {
                if (lI.getQuantity() < 1) {
                    lI.setQuantity(lI.getQuantity() - 1);
                } else {
                    list.remove(lI);
                    return;
                }
            }
        }
    }
   /* public void deleteProduct(ListItem I) {
        long id = I.getId();
        for(ListItem lI : list){
            if(lI.getId() == id){
                if(lI.getQuantity()<1)
                {
                    lI.setQuantity(lI.getQuantity()-1);
                }
                else {
                    list.remove(lI);
                    return;
                }
            }

        }
    }
    public ListItem getItemByID(long id) {
        for (ListItem lI : list) {
            if (lI.getId() == id) {
                return lI;
            }
        }
        return null;
    }
    public void changeNum(Product p, int c){
        long id = p.getId();
        String name = p.getName();

        for(ListItem pr : list){
            if(pr.getId() == id){
                pr.setQuantity(c);
                return;
            }
            else if(p.getName().equals(name)){
                pr.setQuantity(c);
                return;
            }
        }
        System.out.println("Das Produkt mit der ID " + id + " steht nicht auf ihrer Einkaufsliste");
    }
    public void changeNumById(long id, int c){
        for(ListItem p : list){
            if(p.getId() == id){
                p.setQuantity(c);
                return;
            }
        }
        System.out.println("Das Produkt mit der ID " + id + " steht nicht auf ihrer Einkaufsliste");
    }
    public void changeNumByName(String name, int c){
        for(ListItem p : list){
            if(p.getP().equals(name)){
                p.setQuantity(c);
                return;
            }
        }
        System.out.println("Das Produkt mit dem Namen " + name + " steht nicht auf ihrer Einkaufsliste");
    }

    /*@Override
    public String toString() {
        String s = "";
        for(product p: this.list){
            String s1 = p.getName() + " Anzahl: " + p.getCount() + "\n";
            s += s1;
        }
        return "shoppinglist: " + this.name + " {" + "\n" +
                s + '}';
    }

    public List <product> sortListAlphabetic(){ //hier wird derzeit die Instanzvariable list veraendert und dann auchnochmal returnt. das ist doppelt gemoppelt

        //ArrayList<product> alphabetic= new ArrayList();
        Collections.sort(list, new Comparator<product>() {
            @Override
            public int compare(product o1, product o2) {

                String o1Name = o1.getName();
                String o2Name = o2.getName();

                /*
                0 = beide Strings haben gleichen Wert
                >0 = der erste String ist lexicographisch größer als der zweite
                <0 = der erste String ist kleiner

                return o1Name.compareTo(o2Name);

                //return 0;
            }
        });

        return list;
    }

    public void setId(Long id) {
        this.id = id;
    }
*/
}
